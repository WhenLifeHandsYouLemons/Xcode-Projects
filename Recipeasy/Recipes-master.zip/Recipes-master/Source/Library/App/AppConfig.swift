//
//  AppConfig.swift
//  Recipes
//
//  Created by Khoa Pham on 25.02.2018.
//  Copyright © 2018 Khoa Pham. All rights reserved.
//

import Foundation

/// Configurations and keys for this app
struct AppConfig {

  /// API key for food2fork
  static let apiKey = "f1c105dd473738d96661a5a644ba4815"
}
